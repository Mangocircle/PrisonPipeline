To use: 

1. Extract both predictor_app.py and nn.keras files
2. Ensure that Tensorflow, Numpy, pandas, and SciKit Learn are installed on your machines/virtual environments. 
NOTE: It's highly recommended to use Google's Colaboratory for this. 
3. run the app from the terminal by navigating to the directory housing the app, then running: 

python predictor_app.py

If initialized correctly, you will see the following information: 

 This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
To enable the following instructions: AVX2 FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
